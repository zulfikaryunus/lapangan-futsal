<?php
   $hostname  = "localhost";
   $username  = "root";
   $password  = "";
   $dbname  = "latihan";
   $db = new mysqli($hostname, $username, $password, $dbname);
?>